<?php
 require_once("header.php");
?>



  <br>
    <br>
    <br>
    <br>
    <br>
<?php
    require_once("../connection.php");
   
  
    $fetch = "select * from appoinment";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);

    if ($num > 0) {
      echo "<div class='container-fluid'><table class='table table-border' id='myTable'>
      <thead>
           <tr>
               <th>Id</th>
               <th>hospital_id</th>
               <th>User_id</th>
               <th>Timing</th>
               <th>Date</th>
               <th>Fees</th>
              
              
              
              
           </tr> </thead><tbody>";
           
       while($rec = mysqli_fetch_array($execute)){



            echo" <tr>
                <td>$rec[0]</td>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[4]</td>
                <td>$rec[5]</td>

               
            </tr> ";
       }
           echo "</tbody> </table></div>";
    } else {
        header("location:");
    }
    ?>
    <?php
    require_once("footer.php");
?>
    <br>
    <br>
    <br>
    <br>
    <br>



