<?php
    require_once("../connection.php");
    require_once("header.php");
    $fetch = "select * from appoinment";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);
?>



 
<br>
<br>
<br>
<br>
<br>
<?php
    if ($num > 0) {
      echo "<div class='container-fluid'><table class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Hospital ID</th>
               <th>User ID</th>
               <th>Timing</th>
               <th>Date</th>
               <th>Fees </th>
              
              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){
            ?> <tr>
                <td><?php  echo $rec[0]; ?> </td>
                <td><?php $q = mysqli_query($con, "select * from hospital where Id = $rec[1]");
                        $a = mysqli_fetch_array($q);
                        echo $a[2];
                ?></td>
                 <td><?php $q = mysqli_query($con, "select * from user where Id = $rec[2]");
                        $a = mysqli_fetch_array($q);
                        echo $a[2];
                        ?></td>
                <td><?php echo $rec[3] ?></td>
                <td><?php echo $rec[4] ?></td>
                <td><?php echo $rec[5] ?></td>

            </tr>
   <?php    }
           echo "</table></div>";
    } 
    
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <?php
    require_once("Footer.php");


?>