
<?php
    require_once("../connection.php");
    require_once("header.php");
    $fetch = "select * from user where role_id = 1";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);

    if ($num > 0) {
      echo "<div class='container-fluid'><table class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Name</th>
               <th>Email</th>
               <th>Hospital Name</th>
               <th>Address</th>
               <th>Date and Time</th>
               <th>Status</th>
               <th>Approval</th>
              
   </tr>";
  
       while($rec = mysqli_fetch_array($execute)){



      


            ?> <tr>
                <td><?php echo $rec[0] ?></td>
                <td><?php echo $rec[2] ?></td>
                <td><?php echo $rec[3] ?></td>
                <td><?php echo $rec[7] ?></td>
                <td><?php echo $rec[8] ?></td>
                <td><?php echo $rec[9] ?></td>
                <td><?php echo $rec[10] ?></td>
                <?php if($rec[10] == "approved"){ ?>
                <td><a href='hospital_approvel.php?id=<?php echo $rec[0]?>'>Reject</a></td>
                    
            <?php    } else{ ?>
                <td><a href='hospital_approvel.php?id=<?php echo $rec[0]?>'>Give Approval</a></td>
            </tr>
      <?php }}
           echo "</table>";
    } else {
        header("location:");
    }
    

    require_once("Footer.php");


?>