<?php
    require_once("../connection.php");
    require_once("header.php");
    $fetch = "select * from result";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);
?>



 
<br>
<br>
<br>
<a href="export.php"><button type="button"class="btn btn-primary" style="width:80px;">Export</button></a> 
<br>
<br>
<br>
<br>
<?php
    if ($num > 0) {
      echo "<div class=''><table class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Hospital ID</th>
               <th>User ID</th>
               <th>Timing</th>
               <th>Date</th>
               <th>Result</th>
              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){
            echo" <tr>
                <td>$rec[0]</td>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[4]</td>
                <td>$rec[5]</td>
             
            </tr>";
       }
           echo "</table></div>";
    } 
    
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <?php
    require_once("Footer.php");


?>