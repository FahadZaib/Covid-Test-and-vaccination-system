<?php
 require_once("header.php");
?>



  <br>
    <br>
    <br>
    <br>
    <br>
<?php
    require_once("../connection.php");
   
  
    $fetch = "select * from addvaccination";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);

    if ($num > 0) {
      echo "<div class='container-fluid'><table id='myTable' class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Vaccine</th>
               <th>Brand</th>
               <th>Dose</th>
               <th>Fees</th>
               <th>Status</th>

              
              
              
              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){



            echo" <tr>
                <td>$rec[0]</td>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[4]</td>
                <td>$rec[5]</td>


               
            </tr>";
       }
           echo "</table>";
    } else {
        header("location:");
    }
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php
    require_once("Footer.php");


?>


