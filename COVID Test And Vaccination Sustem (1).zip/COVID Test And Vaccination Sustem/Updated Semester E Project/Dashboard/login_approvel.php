<?php
    require_once("../connection.php");
    require_once("header.php");
    $fetch = "select * from user where role_id = 1 and status = 'approved'";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);

    if ($num > 0) {
      echo "<div class='container-fluid'><table class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Name</th>
               <th>Email</th>
               <th>Hospital Name</th>
               <th>Address</th>
               <th>Date and Time</th>

              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){
            echo" <tr>
                <td>$rec[0]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[7]</td>
                <td>$rec[8]</td>
                <td>$rec[9]</td>
                
            </tr>";
       }
           echo "</table>";
      } else {
        header("location:");
    }
    

    require_once("Footer.php");


?>