<?php
    require_once("../connection.php");
    $fetch = "select * from result";
    $execute = mysqli_query($con,$fetch);
    // $num = mysqli_num_rows($execute);


  $html = '<table>
           <tr>
               <th>Id</th>
               <th>Hospital ID</th>
               <th>User ID</th>
               <th>Timing</th>
               <th>Date</th>
               <th>Result</th>
              
           </tr>';
       while($rec = mysqli_fetch_assoc($execute)){
            $html.= ' <tr><td>'.$rec['id'].'</td><td>'.$rec['hospital_id'].'</td><td>'.$rec['user_id'].'</td><td>'.$rec['time'].'</td><td>'.$rec['date'].'</td><td>'.$rec['result'].'</td>
           
             
            </tr>';
       }
      $html .='</table>';
      header('Content-Type:application/xls');
      header('Content-Disposition:attachment;filename=Covid report.xls');
       echo $html;
       ?>