-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2022 at 04:45 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `corono`
--

-- --------------------------------------------------------

--
-- Table structure for table `addvaccination`
--

CREATE TABLE `addvaccination` (
  `id` int(11) NOT NULL,
  `vaccine` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `dose` varchar(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addvaccination`
--

INSERT INTO `addvaccination` (`id`, `vaccine`, `brand`, `dose`, `fees`, `Status`) VALUES
(1, 'pfizer', 'gsk', '3', '3000', ''),
(2, 'Sinopharm ', 'Beijing', '2', '2000', '');

-- --------------------------------------------------------

--
-- Table structure for table `appoinment`
--

CREATE TABLE `appoinment` (
  `id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `timing` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'nonapproved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appoinment`
--

INSERT INTO `appoinment` (`id`, `hospital_id`, `user_id`, `timing`, `day`, `fees`, `status`) VALUES
(8, 2, 15, '17:30to18:30', '2022-10-18', '1600', 'approved'),
(13, 2, 3, '15:32to16:32', '2022-10-10', '1600', 'nonapprove'),
(14, 2, 3, '17:30to18:30', '2022-10-10', '1600', 'nonapprove'),
(15, 2, 3, '15:32to16:32', '2022-10-10', '1600', 'nonapprove'),
(16, 2, 3, '17:30to18:30', '2022-10-10', '1600', 'nonapprove'),
(17, 2, 3, '15:32to16:32', '2022-10-10', '1600', 'nonapprove'),
(18, 2, 3, '17:30to18:30', '2022-10-18', '1600', 'nonapprove'),
(19, 2, 3, '17:30to18:30', '2022-10-18', '1600', 'nonapprove'),
(20, 2, 3, '15:32to16:32', '2022-10-10', '1600', 'nonapprove'),
(21, 2, 3, '15:32to16:32', '2022-10-10', '1600', 'nonapprove'),
(22, 2, 2, '15:32to16:32', '2022-10-10', '1600', 'nonapprove'),
(23, 4, 3, '15:32to16:32', '2022-10-10', '1800', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `approvevaccine`
--

CREATE TABLE `approvevaccine` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vaccine_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'nonapproved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approvevaccine`
--

INSERT INTO `approvevaccine` (`id`, `user_id`, `vaccine_id`, `status`) VALUES
(1, 3, 1, 'approved'),
(2, 3, 1, 'approved'),
(3, 3, 1, 'nonapproved'),
(4, 3, 2, 'nonapproved');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`id`, `user_id`, `name`, `email`, `address`, `time`) VALUES
(1, 1, 'shaheer', 'shaheer@gmail.com', 'asc street', '2022-10-06 16:44:02'),
(2, 1, 'basit', 'basit@gmail.com', 'cde Street', '2022-10-06 16:45:14'),
(3, 14, 'zubair hospital', 'zubair@gmail.com', 'abc street', '2022-10-06 17:13:00'),
(4, 16, 'Al Khidmat', 'demo@gmail.com', 'Nazimabad no 1', '2022-10-11 16:06:01'),
(5, 19, 'jj', 'fahad@gmail.com', 'll', '2022-10-19 12:05:53'),
(6, 21, 'usama hospital', 'usama@gmail.com', 'golimar', '2022-10-22 10:47:12'),
(7, 22, 'Agha Khan Hospital', 'aghakhan@gmail.com', 'Aga Khan University Hospital Laboratory Specimen Collection Unit', '2022-10-22 17:42:35');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_contact`
--

CREATE TABLE `hospital_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `msg` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital_contact`
--

INSERT INTO `hospital_contact` (`id`, `name`, `email`, `phone`, `country`, `msg`) VALUES
(1, 'fahad hospital', 'fahad@gmail.com', '03132993891', 'South Korea', 'problum');

-- --------------------------------------------------------

--
-- Table structure for table `patient_contact`
--

CREATE TABLE `patient_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `msg` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_contact`
--

INSERT INTO `patient_contact` (`id`, `name`, `email`, `phone`, `country`, `msg`) VALUES
(1, 'Fahad Zaib', 'fahadzaib@gmail.com', '03162651782', 'Pakistan', 'Hello World'),
(2, 'usama', 'usama@gmail.com', '03142933087', 'India', 'Bye World');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `hospital_id`, `user_id`, `time`, `date`, `result`) VALUES
(1, 2, 15, '17:30to18:30', '2022-10-18', 'Negative'),
(4, 4, 3, '15:32to16:32', '2022-10-10', 'Negative');

-- --------------------------------------------------------

--
-- Table structure for table `settime`
--

CREATE TABLE `settime` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `starttime` varchar(50) NOT NULL,
  `endtime` varchar(50) NOT NULL,
  `date` varchar(255) NOT NULL,
  `fees` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settime`
--

INSERT INTO `settime` (`id`, `user_id`, `starttime`, `endtime`, `date`, `fees`) VALUES
(8, 14, '15:32', '16:32', '2022-10-10', '2500'),
(9, 2, '17:30', '18:30', '2022-10-18', '1600');

-- --------------------------------------------------------

--
-- Table structure for table `test_shadule`
--

CREATE TABLE `test_shadule` (
  `id` int(11) NOT NULL,
  `hospitalname` varchar(255) NOT NULL,
  `TestTiming` varchar(255) NOT NULL,
  `testdate` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `fees` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `test_shadule`
--

INSERT INTO `test_shadule` (`id`, `hospitalname`, `TestTiming`, `testdate`, `address`, `fees`) VALUES
(1, 'fahad hospital', '03:00 am to 5:00 am', 'Monday', 'xyz street', 2500);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `cnic` varchar(255) DEFAULT NULL,
  `hospitalname` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `date_time` varchar(255) DEFAULT current_timestamp(),
  `status` varchar(255) NOT NULL DEFAULT 'nonapproved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role_id`, `name`, `email`, `password`, `phone`, `cnic`, `hospitalname`, `address`, `date_time`, `status`) VALUES
(1, 0, 'Moeez Ahmed Khan', 'admin@gmail.com', 'admin', NULL, NULL, NULL, NULL, '9/24/2022', 'nonapproved'),
(2, 1, 'fahad', 'fahad@gmail.com', '123', NULL, NULL, 'fahad hospital', 'xyz street', '2022-10-01 15:59:59', 'approved'),
(3, 2, 'zaib', 'zaib@gmail.com', '123', '03162651782', '4240178927891', NULL, 'abc street', '2022-10-01 16:11:14', 'approved'),
(4, 1, 'emmad', 'emmad@gmail.com', '123', NULL, NULL, 'emmad hospital', 'cde Street', '2022-10-06 16:39:54', 'approved'),
(6, 1, 'shaheer', 'shaheer@gmail.com', '123', NULL, NULL, 'shaheer hospital', 'asc street', '2022-10-06 16:44:02', 'approved'),
(7, 2, 'basit hospital', 'basit@gmail.com', '123', '', '', 'basit hospital', 'cde Street', '2022-10-06 16:45:14', 'approved'),
(14, 1, 'zubair', 'zubair@gmail.com', '123', NULL, NULL, 'zubair hospital', 'abc street', '2022-10-06 17:13:00', 'approved'),
(15, 2, 'umair', 'umair@gmail.com', '123', '031872671', '', NULL, 'abs', '2022-10-10 18:12:47', 'approved'),
(16, 2, 'demo', 'demo@gmail.com', '123', NULL, NULL, 'Al Khidmat', 'Nazimabad no 1', '2022-10-11 16:06:01', 'approved'),
(17, 2, 'moiz', 'moiz@gmail.com', '123', '03172677', '', NULL, 'insert into users(\"role_id\") values(0)', '2022-10-13 19:17:00', 'nonapproved'),
(18, 2, 'qq', '', '124', '03162651781', '', NULL, 'abc street', '2022-10-13 19:22:31', 'nonapproved'),
(19, 1, ',,', 'fahad@gmail.com', '123', NULL, NULL, 'jj', 'll', '2022-10-19 12:05:53', 'nonapproved'),
(20, 2, 'zaib', 'fahad@gmail.com', '123', '111', '', NULL, 'cde Street', '2022-10-20 16:25:31', 'nonapproved'),
(21, 1, 'usama', 'usama@gmail.com', '123', NULL, NULL, 'usama hospital', 'golimar', '2022-10-22 10:47:12', 'nonapproved'),
(22, 1, 'Fahad Zaib', 'aghakhan@gmail.com', '123', NULL, NULL, 'Agha Khan Hospital', 'Aga Khan University Hospital Laboratory Specimen Collection Unit', '2022-10-22 17:42:35', 'approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addvaccination`
--
ALTER TABLE `addvaccination`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appoinment`
--
ALTER TABLE `appoinment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hospital_id` (`hospital_id`),
  ADD KEY `appoinment_ibfk_2` (`user_id`);

--
-- Indexes for table `approvevaccine`
--
ALTER TABLE `approvevaccine`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `vaccine_id` (`vaccine_id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `hospital_contact`
--
ALTER TABLE `hospital_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_contact`
--
ALTER TABLE `patient_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hospital_id` (`hospital_id`);

--
-- Indexes for table `settime`
--
ALTER TABLE `settime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_shadule`
--
ALTER TABLE `test_shadule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addvaccination`
--
ALTER TABLE `addvaccination`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appoinment`
--
ALTER TABLE `appoinment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `approvevaccine`
--
ALTER TABLE `approvevaccine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hospital_contact`
--
ALTER TABLE `hospital_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient_contact`
--
ALTER TABLE `patient_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settime`
--
ALTER TABLE `settime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `test_shadule`
--
ALTER TABLE `test_shadule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appoinment`
--
ALTER TABLE `appoinment`
  ADD CONSTRAINT `appoinment_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appoinment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `approvevaccine`
--
ALTER TABLE `approvevaccine`
  ADD CONSTRAINT `approvevaccine_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `approvevaccine_ibfk_2` FOREIGN KEY (`vaccine_id`) REFERENCES `addvaccination` (`id`);

--
-- Constraints for table `hospital`
--
ALTER TABLE `hospital`
  ADD CONSTRAINT `hospital_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
