<?php
include_once("header.php");
?>
 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> About Corano</li>
                           </ul>
                           <h1>About Corano</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="about type_one">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6">
                        <div class="heading icon_dark tp_one">
                           <h6>about Corona</h6>
                           <h1>Coronavirus Disease 2019 (COVID-19)</h1>
                           <span class="flaticon-virus icon"></span>
                        </div>
                        <div class="about_content">
                           <p class="description">It is a long established fact that a reader will be distracted . The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look
                              like readable English.
                           </p>
                           <div class="symptoms">
                              <h2>The best way to prevent illness is to avoid being exposed to this virus.</h2>
                              <div class="row">
                                 <div class="col-lg-6">
                                    <ul>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Clean AND disinfect frequently touched surfaces </p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Avoid touching your eyes, nose, and mouth</p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Clean your hands with a hand sanitizer </p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Cover coughs and sneezes</p>
                                       </li>
                                    </ul>
                                 </div>
                                 <div class="col-lg-6">
                                    <ul>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Stay home if you’re sick</p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Wear a facemask if sick</p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Cover your mouth and nose </p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Throw used tissues in trash</p>
                                       </li>
                                       <li>
                                          <span class="flaticon-check"></span>
                                          <p>Ensure solution has at least 70% alcohol.</p>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                           <a href="#" class="theme_btn tp_one">Read More</a>
                        </div>
                     </div>
                     <div class="col-lg-6">
                        <div class="row">
                           <div class="col-lg-6 first_column">
                              <div class="icon_box type_one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                                 <div class="icon">
                                    <img src="assets/image/svg/working-at-home.svg" class="img-fluid svg_image" alt="home" /> <span class="flaticon-virus "></span>
                                 </div>
                                 <div class="content_box">
                                    <h2><a href="#">Stay at Home</a></h2>
                                    <p>It is a long established fact that a reader will be distracted . </p>
                                 </div>
                              </div>
                              <div class="icon_box type_one wow slideInUp" data-wow-delay="100ms" data-wow-duration="1500ms">
                                 <div class="icon">
                                    <img src="assets/image/svg/mask-2.svg" class="img-fluid svg_image" alt="home" /> <span class="flaticon-virus "></span>
                                 </div>
                                 <div class="content_box">
                                    <h2><a href="#">Protect yourself</a></h2>
                                    <p>It is a long established fact that a reader will be distracted . </p>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-6 second_column">
                              <div class="icon_box type_one wow slideInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                                 <div class="icon">
                                    <img src="assets/image/svg/sport-team.svg" class="img-fluid svg_image" alt="home" /> <span class="flaticon-virus "></span>
                                 </div>
                                 <div class="content_box">
                                    <h2><a href="#">Be Supportive</a></h2>
                                    <p>It is a long established fact that a reader will be distracted . </p>
                                 </div>
                              </div>
                              <div class="icon_box type_one last wow slideInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                                 <div class="icon">
                                    <img src="assets/image/svg/smartphone.svg" class="img-fluid svg_image" alt="svg" /> <span class="flaticon-virus "></span>
                                 </div>
                                 <div class="content_box">
                                    <h6>Emergency Contact</h6>
                                    <h2><a href="#">(555) 555-1234</a></h2>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="funfacts type_one">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="heading tp_one text-center text_white icon_dark">
                           <h6>Funfacts</h6>
                           <span class="flaticon-virus icon"></span>
                           <h1>Keep Your Headup & Be Patient</h1>
                        </div>
                     </div>
                  </div>
                  <div class="about_fun_facts">
                     <div class="row">
                        <div class="col-lg-3">
                           <div class="fun_facts_box type_one">
                              <div class="icon">
                                 <img src="assets/image/svg/virus.svg" class="img-fluid svg_image" alt="home" />
                              </div>
                              <h2><span class="counter-value">434595</span>+</h2>
                              <h6>Total Confirmed</h6>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="fun_facts_box type_one">
                              <div class="icon">
                                 <img src="assets/image/svg/partnership.svg" class="img-fluid svg_image" alt="home" />
                              </div>
                              <h2><span class="counter-value" data-count="">170</span></h2>
                              <h6>Countries / Regions</h6>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="fun_facts_box type_one">
                              <div class="icon">
                                 <img src="assets/image/svg/man.svg" class="img-fluid svg_image" alt="home" />
                              </div>
                              <h2><span class="counter-value">111853</span>+</h2>
                              <h6>Total Recoverd</h6>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="fun_facts_box type_one last">
                              <div class="icon">
                                 <img src="assets/image/svg/tombstones.svg" class="img-fluid svg_image" alt="home" />
                              </div>
                              <h2><span class="counter-value">19603</span>+</h2>
                              <h6>Confirmed Deaths</h6>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="doctor type_one bg_white">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 ">
                        <div class="heading   tp_one">
                           <h6>Doctors</h6>
                           <h1>Meet Our Best Doctors</h1>
                           <span class="flaticon-virus icon"></span>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12 padding_zero">
                        <div class="owl-carousel three_items">
                           <div class="doctor_box type_one ">
                              <div class="image_box">
                                 <img src="assets/image/resources/best-doctors1.jpg" class="img-fluid" alt="best-doctors" />
                                 <div class="overlay">
                                    <ul>
                                       <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                       <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                       <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                       <li><a href="#"><i class="fa fa fa-vimeo"></i></a></li>
                                       <li><a href="#"><i class="fa fa-share-alt"></i></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="content_box">
                                 <a href="#" class="contact_doctor"><span class="fa fa-phone"></span>+44 555 67 890</a>
                                 <h2> <a href="#">Dr. Genoveva Leannon </a> </h2>
                                 <small>Internal Medicine</small>
                                 <p>Dr. Will Marvin is an internist in Rochester, MN, and has been in practice between 5–10 years.</p>
                              </div>
                           </div>
                           <div class="doctor_box type_one ">
                              <div class="image_box">
                                 <img src="assets/image/resources/best-doctors2.jpg" class="img-fluid" alt="best-doctors" />
                                 <div class="overlay">
                                    <ul>
                                       <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                       <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                       <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                       <li><a href="#"><i class="fa fa fa-vimeo"></i></a></li>
                                       <li><a href="#"><i class="fa fa-share-alt"></i></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="content_box">
                                 <a href="#" class="contact_doctor"><span class="fa fa-phone"></span>+44 555 67 890</a>
                                 <h2> <a href="#">Alen Bailey </a> </h2>
                                 <small>Head Doctor</small>
                                 <p>Dr. Will Marvin is an internist in Rochester, MN, and has been in practice between 5–10 years.</p>
                              </div>
                           </div>
                           <div class="doctor_box type_one">
                              <div class="image_box">
                                 <img src="assets/image/resources/best-doctors3.jpg" class="img-fluid" alt="best-doctors" />
                                 <div class="overlay">
                                    <ul>
                                       <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                       <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                       <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                       <li><a href="#"><i class="fa fa fa-vimeo"></i></a></li>
                                       <li><a href="#"><i class="fa fa-share-alt"></i></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="content_box">
                                 <a href="#" class="contact_doctor"><span class="fa fa-phone"></span>+44 555 67 890</a>
                                 <h2> <a href="#">Dr. Basil Andrew </a> </h2>
                                 <small>Chief Doctor </small>
                                 <p>Dr. Will Marvin is an internist in Rochester, MN, and has been in practice between 5–10 years.</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
<?php
include_once("footer.php");
?>