<?php
include_once("header.php");
?>
<?php
require_once("../Connection.php");
    $userid = $_GET["id"];
    $execute = mysqli_query($con , "select * from user where id = '$userid'");
    $data = mysqli_fetch_array($execute);

?>
 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="index.php">Home</a></li>
                              <li class="bread_crumb-item active"> Edit Profile</li>
                           </ul>
                           <h1>Edit Profile</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
          
            <!-- info-section end -->
            <section class="contact_form type_one " >
               <div id="bubbles">
                  <figure class="image bubble_4 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-1.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_5 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-2.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_6 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-3.png " class="img-fluid " alt="img " />
                  </figure>
               </div>
               <div class="container ">
                  <div class="row ">
                     <div class="col-lg-12 ">
                        <div class="heading icon_dark tp_one ">
                           
                           <h1>Edit Your Profile </h1>
                           <span class="flaticon-virus icon "></span>
                        </div>
                     </div>
                  </div>
                  <div class="row ">
                     <div class="col-lg-7 col-md-12 ">
                        <div class="contact_form_box type_one ">
                           <h2>Edit your Profile Here</h2>
                           <form id="contact-form" method="POST" action="" role="form">
                              <div class="messages"></div>

                              <div class="controls">
                              <div class="row ">
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                       <label> Name</label>
                                       <input type="text" name="name" placeholder="Enter Your Fullname" required="required" data-error="Enter Your Name" value="<?php echo $data[2]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> Email</label>
                                       <input type="email" name="email" placeholder="Enter Valid Email" required="required" data-error="Enter Your Email Id" value="<?php echo $data[3]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> Phone Number</label>
                                       <input type="text" name="phone" placeholder="Enter Valid Number" required="required" data-error="Enter Valid Number" value="<?php echo $data[5]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> CNIC</label>
                                       <input type="text" name="cnic" placeholder="Enter Valid CNIC" required="required" data-error="Enter Valid Number" value="<?php echo $data[6]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> Address</label>
                                       <input type="text" name="address" placeholder="Enter Valid Address" required="required" data-error="Enter Valid Number" value="<?php echo $data[8]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                
                                 <div class="col-lg-12 col-md-12 ">
                                    <div class="form-group mg_top apbtn">
                                       <button class="theme_btn tp_one" type="submit" name="login_btn">Update</button>
                                    </div>
                                 </div>
                                 </div>
                           </div>
                           </form>
                        </div>
                     </div>
                     <div class="col-lg-5 ">
                        <div class="image_box clearfix ">
                           <figure class="image image_1 wow bounceInDown " data-wow-delay="00ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-1.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_2 wow bounceInDown " data-wow-delay="100ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-2.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_3 wow bounceInDown " data-wow-delay="200ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-3.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_4 wow bounceInDown " data-wow-delay="300ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-4.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_5 wow bounceInDown " data-wow-delay="400ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-5.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_6 wow bounceInDown " data-wow-delay="500ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-6.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_bg ">
                              <img src="assets/image/resources/home-1-contact-bg.png " class="img-fluid " alt="img " />
                           </figure>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="map-section">
               <!--Map Outer-->
               <div class="map-outer">
                  <div class="google-map" id="contact-google-map" data-map-lat="44.231172" data-map-lng="-76.485954" data-icon-path="assets/image/health.png" data-map-title="Alabama, USA" data-map-zoom="12" data-markers='{
                     "marker-1": [42.231172, -84.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-2": [44.231172, -76.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-3": [40.880550, -78.393705, "<h4>Branch Office</h4><p>4/99 Pennsylvania, USA</p>"]
                     }'>
                  </div>
               </div>
            </section>
<?php
include_once("footer.php");
?>

<?php
    if (isset($_POST["login_btn"])) {
        
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $cnic = $_POST["cnic"];
        $address = $_POST["address"];
        
        

        // $update = "UPDATE `user` SET 
        // `Name`='$name',`Email`='$email',`Approval`='$status'
        //  WHERE id = $userid";



$update = "UPDATE `user` SET `name`='$name',`email`='$email',`phone`='$phone',`cnic`='$cnic',`address`='$address' WHERE id = $userid";



         $run = mysqli_query($con , $update);

         if ($run) {
             echo "<script>
             window.location.href='patient_details.php';
             </script>";
         } else {
             echo mysqli_error($con);
         }
        }

        ?>