<?php
require_once("header.php");
?>
<br><br>
<?php
require_once("../Connection.php");
    $userid = $_GET["id"];
    $execute = mysqli_query($con , "select * from user where id = '$userid'"); 
    $data = mysqli_fetch_array($execute);

?>

<div class="container mt-5">
<form method="POST">
<div class="form-group">
    <label for="exampleInputEmail1">ID</label>
    <input type="text" name="id" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required  value="<?php echo $data[0]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required  value="<?php echo $data[2]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required value="<?php echo $data[3]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Phone Number</label>
    <input type="text" name="phone" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required value="<?php echo $data[5]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">CNIC</label>
    <input type="text" name="cnic" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required value="<?php echo $data[6]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Address</label>
    <input type="text" name="address" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required value="<?php echo $data[8]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Date and Time</label>
    <input type="text" name="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required value="<?php echo $data[9]?>" readonly/>
  </div>
  
 


<br>
<br>

<div class="d-flex flex-row align-items-center mb-4"> 
                   
                    <div class="form-outline flex-fill mb-0">
                        <select name="status" class="form-control">
                           
                            <option value="approved" <?php if($data[10] == "approved") { echo "selected";} ?>>Approved</option>
                            <option value="nonapproved" <?php if($data[10] == "nonapproved") { echo "selected";} ?>>Non Approved</option>
                        </select>
                    </div>
                  </div>





  <button type="submit" name="login_btn" class="btn btn-primary">Submit</button>

</form>
</div>
<br>
<br>
<!-- JavaScript Bundle with Popper -->

<?php
require_once("footer.php");
?>



<?php
    if (isset($_POST["login_btn"])) {
        $id = $_POST["id"];
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $cnic = $_POST["cnic"];
        $address = $_POST["address"];
        $datetime = $_POST["date"];
        $status = $_POST["status"];

        // $update = "UPDATE `user` SET 
        // `Name`='$name',`Email`='$email',`Approval`='$status'
        //  WHERE id = $userid";



$update = "UPDATE `user` SET `id`='$id',`name`='$name',`email`='$email',`phone`='$phone',`cnic`='$cnic',`address`='$address',`date_time`='$datetime',`status`='$status' WHERE id = $userid";



         $run = mysqli_query($con , $update);

         if ($run) {
             echo "<script>
             window.location.href='permission.php';
             </script>";
         } else {
             echo mysqli_error($con);
         }
         


       
        

    }

?>