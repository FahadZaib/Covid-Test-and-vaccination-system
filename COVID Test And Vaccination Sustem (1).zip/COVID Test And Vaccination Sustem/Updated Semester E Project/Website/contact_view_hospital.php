<?php
 require_once("header.php");
?>


<section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> Patient Contacts</li>
                           </ul>
                           <h1>Patient Contacts</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>


  <br>
    <br>
    <br>
    <br>
    <br>
<?php
    require_once("../connection.php");
   
  
    $fetch = "select * from hospital_contact";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);

    if ($num > 0) {
      echo "<div class='container-fluid'><table class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Name</th>
               <th>Email</th>
               <th>Phone</th>
               <th>Country</th>
               <th>Massege</th>

              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){
            echo" <tr>
                <td>$rec[0]</td>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[4]</td>
                <td>$rec[5]</td>
         
            </tr>";
       }
           echo "</table>";
    } else {
        header("location:");
    }
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php
    require_once("Footer.php");


?>