<?php
include_once("header.php");
$ids = $_SESSION["id"];
$fetch = "select * from user where id = '$ids'";

$execute = mysqli_query($con,$fetch);
//  $num = mysqli_num_rows($execute);
$rec = mysqli_fetch_array($execute)
?>
 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> Contact</li>
                           </ul>
                           <h1>Contact</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- info-section -->
            <section class="info_section">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="heading text-center tp_one ">
                           <h6>Get In Touch</h6>
                           <h1>We’re Here to Help You Contact Us</h1>
                           <span class="flaticon-virus icon "></span>
                        </div>
                     </div>
                  </div>
                  <div class="info_inner">
                     <div class="row ">
                        <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                           <div class="info-box">
                              <div class="hidden-icon"><i class="flaticon-address"></i></div>
                              <div class="box">
                                 <div class="icon-box"><i class="flaticon-address"></i></div>
                                 <h4>Location</h4>
                                 <span>Visit to explore the world</span>
                              </div>
                              <div class="text">
                                 <p>124, Queens walk 2nd cross<br />newyork 5241.</p>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                           <div class="info-box">
                              <div class="hidden-icon"><i class="flaticon-phone-1"></i></div>
                              <div class="box">
                                 <div class="icon-box"><i class="flaticon-phone-1"></i></div>
                                 <h4>Make a Call</h4>
                                 <span>Let’s talk with our experts</span>
                              </div>
                              <div class="text">
                                 <p><a href="tel:4455567890">+44 555 67 890</a></p>
                                 <p>Mon - Fri: 09.00 to 18.00</p>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12 info-column">
                           <div class="info-box">
                              <div class="hidden-icon"><i class="flaticon-mail"></i></div>
                              <div class="box">
                                 <div class="icon-box"><i class="flaticon-mail"></i></div>
                                 <h4>Send a Mail</h4>
                                 <span>Dont’s hesitate to mail</span>
                              </div>
                              <div class="text">
                                 <p><a href="mailto:career@example.com">career@example.com</a></p>
                                 <p><a href="mailto:info@example.com">info@example.com</a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- info-section end -->
            <section class="contact_form type_one " >
               <div id="bubbles">
                  <figure class="image bubble_4 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-1.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_5 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-2.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_6 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-3.png " class="img-fluid " alt="img " />
                  </figure>
               </div>
               <div class="container ">
                  <div class="row ">
                     <div class="col-lg-12 ">
                        <div class="heading icon_dark tp_one ">
                           <h6>Get in Touch</h6>
                           <h1>Contact With Us </h1>
                           <span class="flaticon-virus icon "></span>
                        </div>
                     </div>
                  </div>
                  <div class="row ">
                     <div class="col-lg-7 col-md-12 ">
                        <div class="contact_form_box type_one ">
                           <h2>Send us a message, We will be touch <br>with you shortly.</h2>
                           <form id="contact-form" method="POST" action="" role="form">
                              <div class="messages"></div>

                              <div class="controls">
                              <div class="row ">
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                       <label> Name</label>
                                       <input type="text" name="name" placeholder="Enter Your Fullname" required="required" data-error="Enter Your Name"value="<?php echo $rec[2]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> Email</label>
                                       <input type="email" name="email" placeholder="Enter Valid Email" required="required" data-error="Enter Your Email Id"value="<?php echo $rec[3]?>">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> Phone</label>
                                       <input type="text" name="phone" placeholder="Enter Valid Number" required="required" data-error="Enter Valid Number">
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 "> 
                                    <div class="form-group">
                                       <label>Country of Travel</label>
                                       <select name="country" id="country" required="required">
                                       <option >Select Country</option>
                                          <option value="Pakistan">Pakistan</option>
                                          <option value="India">India</option>
                                          <option value="South Korea">South Korea</option>
                                          <option value="North Korea">North Korea</option>
                                          <option value="Japan">Japan</option>
                                          <option value="China">China</option>
                                          <option value="England">England</option>
                                          <option value="Netherland">Netherland</option>
                                       </select>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-12 col-md-12 ">
                                    <div class="form-group">
                                        <label> Message</label>
                                       <textarea name="message" placeholder="Enter Your Message" required="required"  rows="3" data-error="Please, leave us a message."></textarea>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-12 col-md-12 ">
                                    <div class="form-group mg_top apbtn">
                                       <button class="theme_btn tp_one" type="submit" name="btn">Send Message</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           </form>
                        </div>
                     </div>
                     <div class="col-lg-5 ">
                        <div class="image_box clearfix ">
                           <figure class="image image_1 wow bounceInDown " data-wow-delay="00ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-1.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_2 wow bounceInDown " data-wow-delay="100ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-2.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_3 wow bounceInDown " data-wow-delay="200ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-3.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_4 wow bounceInDown " data-wow-delay="300ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-4.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_5 wow bounceInDown " data-wow-delay="400ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-5.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_6 wow bounceInDown " data-wow-delay="500ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-6.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_bg ">
                              <img src="assets/image/resources/home-1-contact-bg.png " class="img-fluid " alt="img " />
                           </figure>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="map-section">
               <!--Map Outer-->
               <div class="map-outer">
                  <div class="google-map" id="contact-google-map" data-map-lat="44.231172" data-map-lng="-76.485954" data-icon-path="assets/image/health.png" data-map-title="Alabama, USA" data-map-zoom="12" data-markers='{
                     "marker-1": [42.231172, -84.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-2": [44.231172, -76.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-3": [40.880550, -78.393705, "<h4>Branch Office</h4><p>4/99 Pennsylvania, USA</p>"]
                     }'>
                  </div>
               </div>
            </section>
<?php
include_once("footer.php");
?>


<?php

if (isset($_POST["btn"])) {

 $name = $_POST["name"];
 $email = $_POST["email"];
 $phone = $_POST["phone"];
 $country = $_POST["country"];
 $message = $_POST["message"];


 $query = "INSERT INTO  `patient_contact`(`name`, `email`, `phone`, `country`, `msg`) VALUES ('$name','$email','$phone','$country','$message')";
 $run = mysqli_query($con , $query);
 if ($run == true) {
    echo '<script>          
    alert("Your Message sand Saccufully");
    </script>';
} else {
    echo mysqli_error($con);
}



}




?>
    