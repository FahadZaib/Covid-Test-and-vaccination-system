<?php
include_once("header.php");
?>
<?php
require_once("../Connection.php");
    $userids = $_GET["idS"];
    $execute = mysqli_query($con , "select * from appoinment where id = '$userids'");
    $data = mysqli_fetch_array($execute);

?>
 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="index.php">Home</a></li>
                              <li class="bread_crumb-item active">Result Update</li>
                           </ul>
                           <h1>Result Update</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
          
            <!-- info-section end -->
            <section class="contact_form type_one " >
               <div id="bubbles">
                  <figure class="image bubble_4 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-1.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_5 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-2.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_6 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-3.png " class="img-fluid " alt="img " />
                  </figure>
               </div>
               <div class="container ">
                  <div class="row ">
                     <div class="col-lg-12 ">
                        <div class="heading icon_dark tp_one ">
                           
                           <h1>Edit Your Profile </h1>
                           <span class="flaticon-virus icon "></span>
                        </div>
                     </div>
                  </div>
                  <div class="row ">
                     <div class="col-lg-7 col-md-12 ">
                        <div class="contact_form_box type_one ">
                           <h2>Edit your Profile Here</h2>
                           <form id="contact-form" method="POST" action="" role="form">
                              <div class="messages"></div>

                              <div class="controls">
                              <div class="row ">
                               
                                
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> Hospital ID</label>
                                       <input type="text" name="hospitalid" placeholder="Enter Valid Number" required="required" data-error="Enter Valid Number" value="<?php echo $data[1]?> "readonly>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label> User ID </label>
                                       <input type="text" name="userid" placeholder="Enter Valid CNIC" required="required" data-error="Enter Valid Number" value="<?php echo $data[2]?>" readonly>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label>Timing</label>
                                       <input type="text" name="timing" placeholder="Enter Valid Address" required="required" data-error="Enter Valid Number" value="<?php echo $data[3]?>" readonly>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label>Date</label>
                                       <input type="text" name="date" placeholder="Enter Valid Address" required="required" data-error="Enter Valid Number" value="<?php echo $data[4]?>" readonly>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group "> <label>Update Result</label>
                                    <div class="form-outline flex-fill mb-0">
                        <select name="result" class="form-control">
                           
                            <option value="Negative" <?php if($data[6] == "Negative") { echo "selected";} ?>>Negative</option>
                            <option value="Positive" <?php if($data[6] == "Positive") { echo "selected";} ?>>Positive</option>
                        </select>
                    </div>
                                    </div>
                                 </div>
                                
                                 <div class="col-lg-12 col-md-12 ">
                                    <div class="form-group mg_top apbtn">
                                       <button class="theme_btn tp_one" type="submit" name="login_btn">Update</button>
                                    </div>
                                 </div>
                                 </div>

                                 <div class="d-flex flex-row align-items-center mb-4">
                   
                   
                  </div>
                           </div>
                           </form>
                        </div>
                     </div>
                     <div class="col-lg-5 ">
                        <div class="image_box clearfix ">
                           <figure class="image image_1 wow bounceInDown " data-wow-delay="00ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-1.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_2 wow bounceInDown " data-wow-delay="100ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-2.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_3 wow bounceInDown " data-wow-delay="200ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-3.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_4 wow bounceInDown " data-wow-delay="300ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-4.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_5 wow bounceInDown " data-wow-delay="400ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-5.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_6 wow bounceInDown " data-wow-delay="500ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-6.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_bg ">
                              <img src="assets/image/resources/home-1-contact-bg.png " class="img-fluid " alt="img " />
                           </figure>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="map-section">
               <!--Map Outer-->
               <div class="map-outer">
                  <div class="google-map" id="contact-google-map" data-map-lat="44.231172" data-map-lng="-76.485954" data-icon-path="assets/image/health.png" data-map-title="Alabama, USA" data-map-zoom="12" data-markers='{
                     "marker-1": [42.231172, -84.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-2": [44.231172, -76.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-3": [40.880550, -78.393705, "<h4>Branch Office</h4><p>4/99 Pennsylvania, USA</p>"]
                     }'>
                  </div>
               </div>
            </section>
<?php
include_once("footer.php");
?>

<?php
    if (isset($_POST["login_btn"])) {
        
        $hospitalid = $_POST["hospitalid"];
        $userid = $_POST["userid"];
        $timing = $_POST["timing"];
        $date = $_POST["date"];
        $result = $_POST["result"];
        

$query = "INSERT INTO `result`(`hospital_id`, `user_id`, `time`, `date`, `result`) VALUES ('$hospitalid','$userid ','$timing','$date','$result')";

$run = mysqli_query($con , $query);
if ($run == true) {
    echo '<script> 
    alert("Result Updated");         
    window.location.href="test_result.php";
    </script>';
} else {
    echo mysqli_error($con);
}



       
        }

        ?>