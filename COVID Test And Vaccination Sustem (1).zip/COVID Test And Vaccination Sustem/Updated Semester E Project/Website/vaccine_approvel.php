<?php
require_once("header.php");
?>

<?php
require_once("../Connection.php");
   $useridd = $_GET["id"];
    $execute = mysqli_query($con , "select * from approvevaccine");
    $data = mysqli_fetch_array($execute);

?>

<div class="container mt-5">
<form method="POST">
<div class="form-group">
    <label for="exampleInputEmail1">ID</label>
    <input type="text" name="id" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required  value="<?php echo $data[0]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">User Id</label>
    <input type="text" name="uid" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required  value="<?php echo $data[1]?>" readonly/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Vacine Id</label>
    <input type="email" name="vaccineid" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required value="<?php echo $data[2]?>" readonly/>
  </div>
 

<br>
<br>

<div class="d-flex flex-row align-items-center mb-4">
                   
                    <div class="form-outline flex-fill mb-0">
                        <select name="status" class="form-control">
                           
                            <option value="approved" <?php if($data[3] == "approved") { echo "selected";} ?>>Approved</option>
                            <option value="nonapproved" <?php if($data[3] == "nonapproved") { echo "selected";} ?>>Non Approved</option>
                        </select>
                    </div>
                  </div>





  <button type="submit" name="login_btn" class="btn btn-primary">Submit</button>

</form>
</div>
<!-- JavaScript Bundle with Popper -->

<?php
require_once("footer.php");
?>



<?php
    if (isset($_POST["login_btn"])) {

        $vaccineid = $_POST["vaccineid"];
        $uid = $_POST["uid"];
        $status = $_POST["status"];

        // $update = "UPDATE `user` SET 
        // `Name`='$name',`Email`='$email',`Approval`='$status'
        //  WHERE id = $userid";



// $update = "UPDATE `user` SET `id`='$id',`name`='$name',`email`='$email',`hospitalname`='$hospitalname',`address`='$address',`date_time`='$datetime',`status`='$status' WHERE id = $userid";


$update ="UPDATE `approvevaccine` SET `user_id`='$uid',`vaccine_id`='$vaccineid',`status`='$status' WHERE id = $useridd";



         $run = mysqli_query($con , $update);

         if ($run) {
             echo "<script>
             window.location.href='vaccine_app_tbl.php';
             </script>";
         } else {
             echo mysqli_error($con);
         }
         


       
        

    }

?>