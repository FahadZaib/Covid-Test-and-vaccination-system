<?php require_once("header.php"); ?>
<section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> Vaccine</li>
                           </ul>
                           <h1>Vaccination</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>

<?php
    require_once("../connection.php");
    
    $fetch = "select * from addvaccination ";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);
    ?>
<br>
<br>
<br>
<br>
<br>
<?php

    if ($num > 0) {
      echo "<div class='container'><table class='table' id='myTable'> 
      <thead>
           <tr>
               <th>Vaccine Name</th>
               <th>Vacine Brand</th>
               <th>Vacine Dose</th>
               <th>Fees</th>
               <th>Get Appointment</th>
             
              
           </tr>
           </thead>  <tbody>";

       while($rec = mysqli_fetch_array($execute)){
            echo" 
           
            <tr>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[4]</td>
                <td><a href='take_vaccine_appointment.php?id=$rec[0]'>Take Appointment</a></td>
            </tr> ";
       }
           echo "</tbody> </table></div>";
    } else {
        header("location:");
    }
    
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <?php
    require_once("Footer.php");


?>
