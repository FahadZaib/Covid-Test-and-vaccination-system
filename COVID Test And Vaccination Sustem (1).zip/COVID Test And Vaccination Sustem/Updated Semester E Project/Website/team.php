<?php
include_once("header.php");
?>
<main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> Doctors</li>
                           </ul>
                           <h1>Our Team</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!--------doctors-------->
            <section class="team_all">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-4">
                        <div class="doctor_box type_two ">
                           <div class="image_box ">
                              <img src="assets/image/resources/best-doctors1.jpg " class="img-fluid " alt="best-doctors " />
                              <div class="overlay ">
                                 <ul>
                                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                                    <li><a href="# "><i class="fa fa-skype "></i></a></li>
                                    <li><a href="# "><i class="fa fa fa-vimeo "></i></a></li>
                                    <li><a href="# "><i class="fa fa-share-alt "></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="content_box ">
                              <a href="# " class="contact_doctor "><span class="fa fa-phone "></span>+44 555 67 890</a>
                              <div class="text_box ">
                                 <h2> <a href="# ">Dr. Genoveva Leannon </a> </h2>
                                 <small>Internal Medicine</small>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="doctor_box type_two ">
                           <div class="image_box ">
                              <img src="assets/image/resources/best-doctors2.jpg " class="img-fluid " alt="best-doctors " />
                              <div class="overlay ">
                                 <ul>
                                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                                    <li><a href="# "><i class="fa fa-skype "></i></a></li>
                                    <li><a href="# "><i class="fa fa fa-vimeo "></i></a></li>
                                    <li><a href="# "><i class="fa fa-share-alt "></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="content_box ">
                              <a href="# " class="contact_doctor "><span class="fa fa-phone "></span>+44 555 67 890</a>
                              <div class="text_box ">
                                 <h2> <a href="# ">Alen Bailey </a> </h2>
                                 <small>Head Doctor</small>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="doctor_box type_two ">
                           <div class="image_box ">
                              <img src="assets/image/resources/best-doctors3.jpg " class="img-fluid " alt="best-doctors " />
                              <div class="overlay ">
                                 <ul>
                                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                                    <li><a href="# "><i class="fa fa-skype "></i></a></li>
                                    <li><a href="# "><i class="fa fa fa-vimeo "></i></a></li>
                                    <li><a href="# "><i class="fa fa-share-alt "></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="content_box ">
                              <a href="# " class="contact_doctor "><span class="fa fa-phone "></span>+44 555 67 890</a>
                              <div class="text_box ">
                                 <h2> <a href="# ">Dr. Basil Andrew </a> </h2>
                                 <small>Chief Doctor </small>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="doctor_box type_two ">
                           <div class="image_box ">
                              <img src="assets/image/resources/best-doctors1.jpg " class="img-fluid " alt="best-doctors " />
                              <div class="overlay ">
                                 <ul>
                                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                                    <li><a href="# "><i class="fa fa-skype "></i></a></li>
                                    <li><a href="# "><i class="fa fa fa-vimeo "></i></a></li>
                                    <li><a href="# "><i class="fa fa-share-alt "></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="content_box ">
                              <a href="# " class="contact_doctor "><span class="fa fa-phone "></span>+44 555 67 890</a>
                              <div class="text_box ">
                                 <h2> <a href="# ">Dr. Genoveva Leannon </a> </h2>
                                 <small>Internal Medicine</small>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="doctor_box type_two ">
                           <div class="image_box ">
                              <img src="assets/image/resources/best-doctors2.jpg " class="img-fluid " alt="best-doctors " />
                              <div class="overlay ">
                                 <ul>
                                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                                    <li><a href="# "><i class="fa fa-skype "></i></a></li>
                                    <li><a href="# "><i class="fa fa fa-vimeo "></i></a></li>
                                    <li><a href="# "><i class="fa fa-share-alt "></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="content_box ">
                              <a href="# " class="contact_doctor "><span class="fa fa-phone "></span>+44 555 67 890</a>
                              <div class="text_box ">
                                 <h2> <a href="# ">Alen Bailey </a> </h2>
                                 <small>Head Doctor</small>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="doctor_box type_two ">
                           <div class="image_box ">
                              <img src="assets/image/resources/best-doctors3.jpg " class="img-fluid " alt="best-doctors " />
                              <div class="overlay ">
                                 <ul>
                                    <li><a href="# "><i class="fa fa-facebook "></i></a></li>
                                    <li><a href="# "><i class="fa fa-twitter "></i></a></li>
                                    <li><a href="# "><i class="fa fa-skype "></i></a></li>
                                    <li><a href="# "><i class="fa fa fa-vimeo "></i></a></li>
                                    <li><a href="# "><i class="fa fa-share-alt "></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="content_box ">
                              <a href="# " class="contact_doctor "><span class="fa fa-phone "></span>+44 555 67 890</a>
                              <div class="text_box ">
                                 <h2> <a href="# ">Dr. Basil Andrew </a> </h2>
                                 <small>Chief Doctor </small>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
<?php
include_once("footer.php");
?>