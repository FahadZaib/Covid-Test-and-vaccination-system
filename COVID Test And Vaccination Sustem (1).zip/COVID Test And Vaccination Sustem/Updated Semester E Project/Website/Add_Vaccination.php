<?php
include_once("header.php");


    if(!isset( $_SESSION["role"] ))
    {
        header("location:login.php");
    }
   
?>
 

 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="index.php">Home</a></li>
                              <li class="bread_crumb-item active">Add Vaccination</li>
                           </ul>
                           <h1>Vaccination</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
          
            <!-- info-section end -->
            <section class="contact_form type_one " >
               <div id="bubbles">
                  <figure class="image bubble_4 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-1.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_5 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-2.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_6 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-3.png " class="img-fluid " alt="img " />
                  </figure>
               </div>

               <div class="container ">
                  <div class="row ">
                     <div class="col-lg-12 ">
                        <div class="heading icon_dark tp_one ">
                           
                           <h1>Covid Test  </h1>
                           <span class="flaticon-virus icon "></span>
                        </div>
                     </div>
                  </div>
                  <div class="row ">
                     <div class="col-lg-7 col-md-12 ">
                        <div class="contact_form_box type_one ">
                           <h2>Covid Vaccination  Add Here</h2>
                           <form id="contact-form" method="POST" action="" role="form">
                              <div class="messages"></div>

                              <div class="controls">
                              <div class="row ">
                              
                                    <div class="col-lg-6 col-md-6">
                                    <div class="form-group ">
                                       <label>Add Vacine</label>
                                       <input type="text" name="addvacine" placeholder="Add Vacine"  required="required" data-error="Hospital Name"  >
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>

                                 <div class="col-lg-6 col-md-6">
                                    <div class="form-group ">
                                       <label>Brand Name</label>
                                       <input type="text" name="brandname"  placeholder="Brand Name" required="required" data-error="Hospital Name"  >
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>

                                 <div class="col-lg-6 col-md-6">
                                    <div class="form-group ">
                                       <label>Vaccination Dose</label>
                                       <input type="text" name="vaccinationdose" placeholder="Brand Name"  required="required" data-error="Hospital Name"  >
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>

                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                       <label>Fees </label>
                                       <input type="text" name="fees" placeholder="Fees" required="required" data-error="Hospital Fees" >
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                       <label>Status </label>
                                       <select name="sta" class="form-control">
                                          <option value="Available">Available</option>
                                          <option value="Unavailable">Unavailable</option>
                                       </select>
                           
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 col-md-12 ">
                                    <div class="form-group mg_top apbtn">
                                       <button class="theme_btn tp_one" type="submit" name="btn">Set</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
                     <div class="col-lg-5 ">
                        <div class="image_box clearfix ">
                           <figure class="image image_1 wow bounceInDown " data-wow-delay="00ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-1.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_2 wow bounceInDown " data-wow-delay="100ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-2.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_3 wow bounceInDown " data-wow-delay="200ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-3.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_4 wow bounceInDown " data-wow-delay="300ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-4.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_5 wow bounceInDown " data-wow-delay="400ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-5.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_6 wow bounceInDown " data-wow-delay="500ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-6.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_bg ">
                              <img src="assets/image/resources/home-1-contact-bg.png " class="img-fluid " alt="img " />
                           </figure>
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            <section class="map-section">
               <!--Map Outer-->
               <div class="map-outer">
                  <div class="google-map" id="contact-google-map" data-map-lat="44.231172" data-map-lng="-76.485954" data-icon-path="assets/image/health.png" data-map-title="Alabama, USA" data-map-zoom="12" data-markers='{
                     "marker-1": [42.231172, -84.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-2": [44.231172, -76.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-3": [40.880550, -78.393705, "<h4>Branch Office</h4><p>4/99 Pennsylvania, USA</p>"]
                     }'>
                  </div>
               </div>
            </section>

            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>



        <?php

        if (isset($_POST["btn"])) {

         $addvacine = $_POST["addvacine"];
         $brandname = $_POST["brandname"];
         $vaccinationdose = $_POST["vaccinationdose"];
         $fees = $_POST["fees"];
         $sta = $_POST["sta"];

        

   $query = "INSERT INTO `addvaccination`(`vaccine`, `brand`, `dose`, `fees`,`status`)
    VALUES ('$addvacine','$brandname','$vaccinationdose','$fees','$sta')";
         $run = mysqli_query($con , $query);
         if ($run == true) {
            echo '<script>          
            alert("Data Save Saccufully");
            </script>';
        } else {
            echo mysqli_error($con);
        }


        
    }
      


    $select_pass = "select * from `addvaccination`";
    $exec_pass = mysqli_query($con,$select_pass);
    $arr = mysqli_fetch_array($exec_pass);
    $_SESSION["vacineid"] = $arr[0];
?>
            <?php
include_once("footer.php");
?>
 