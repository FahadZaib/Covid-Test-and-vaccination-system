

<?php
session_start();
require_once("../connection.php");
  $userid = $_SESSION["id"];
  $vacineid = $_GET["id"];




  $query = "INSERT INTO `approvevaccine`(`user_id`, `vaccine_id`) VALUES ('$userid','$vacineid')";
         $run = mysqli_query($con , $query);
         if ($run == true) {
            echo '<script>          
            alert("Data Save Saccufully");
            window.location.href="show_vaccine.php";
            </script>';
        } else {
            echo mysqli_error($con);
        }

?>











































