<?php
include_once("header.php");


    if(!isset( $_SESSION["role"] ))
    {
        header("location:login.php");
    }
    
    $ID = $_GET["id"];
    $query = mysqli_query($con , "select * from user where id = $ID");
    $c = mysqli_fetch_array($query);

    $query1 = mysqli_query($con , "select * from settime where user_id = $ID");
    $c1 = mysqli_fetch_array($query1);

?>
 

 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="index.php">Home</a></li>
                              <li class="bread_crumb-item active">Appointment</li>
                           </ul>
                           <h1>Appointment</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
          
            <!-- info-section end -->
            <section class="contact_form type_one " >
               <div id="bubbles">
                  <figure class="image bubble_4 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-1.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_5 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-2.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_6 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-3.png " class="img-fluid " alt="img " />
                  </figure>
               </div>
               <div class="container ">
                  <div class="row ">
                     <div class="col-lg-12 ">
                        <div class="heading icon_dark tp_one ">
                           
                           <h1> Get Appointment </h1>
                           <span class="flaticon-virus icon "></span>
                        </div>
                     </div>
                  </div>
                  <div class="row ">
                     <div class="col-lg-7 col-md-12 ">
                        <div class="contact_form_box type_one ">
                           <h2>Get Covid Test Appointment Here</h2>
                           <form id="contact-form" method="POST" action="" role="form">
                              <div class="messages"></div>

                               <div class="controls">
                              <div class="row ">
                              
                                    <div class="col-lg-6 col-md-6">
                                    <div class="form-group ">
                                       <label>Hospital Name</label>
                                       <input type="text" name="hname" value="<?php echo $c[7]; ?>" placeholder="Enter Hospital Name" required="required" data-error="Hospital Name" readonly >
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>

                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                       <label>Hospital Address</label>
                                       <input type="text" name="address" value="<?php echo $c[8]; ?>" placeholder="Enter Hospital Address" required="required" data-error="Hospital Address" readonly>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>

                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                      <label>Select Timing </label>
                                        <select name="timing" class="form-control">
                                           <?php
                                           $select_pass = "select * from `settime` ";
                                           $exec_pass = mysqli_query($con,$select_pass);
                                           $num_pass = mysqli_num_rows($exec_pass);
                                           if($num_pass > 0)
                                                             {
                                               while ($arr = mysqli_fetch_array($exec_pass)) {?>
                                               <option value="<?php echo $arr[2] . "to" . $arr[3] ?>" ><?php echo $arr[2] ?> <b>pm</b> to <?php echo $arr[3] ?> <b>am</b></option>

                                                 <?php  }}
                                                          ?>    
                                                         </select>
                                  <div class="help-block with-errors"></div>
                              </div>
                            </div>

                            <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                      <label>Select Date </label>
                                        <select name="date" class="form-control">
                                           <?php
                                           $select_pass = "select * from `settime` ";
                                           $exec_pass = mysqli_query($con,$select_pass);
                                           $num_pass = mysqli_num_rows($exec_pass);
                                           if($num_pass > 0)
                                                             {
                                               while ($arr = mysqli_fetch_array($exec_pass)) {?>
                                               <option value="<?php echo $arr[4] ?>" ><?php echo $arr[4] ?></option>

                                                 <?php  }}
                                                          ?>    
                                                         </select>
                                  <div class="help-block with-errors"></div>
                              </div>
                            </div>
                    
                                 <div class="col-lg-6 col-md-6 ">
                                    <div class="form-group ">
                                       <label>Test Fees </label>
                                       <input type="text" name="fees" value="<?php echo $c1[5] ?>" placeholder="Enter Test Fees" required="required" data-error="Hospital Fees" readonly>
                                       <div class="help-block with-errors"></div>
                                    </div>
                                 </div>
                                 
                                 <div class="col-lg-12 col-md-12 ">
                                    <div class="form-group mg_top apbtn">
                                       <button class="theme_btn tp_one" type="submit" name="btn">Send</button>
                                    </div>
                                      </div>
                                 </div>
                            </div>
                           </form>
                        </div>
                     </div>
                     <div class="col-lg-5 ">
                        <div class="image_box clearfix ">
                           <figure class="image image_1 wow bounceInDown " data-wow-delay="00ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-1.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_2 wow bounceInDown " data-wow-delay="100ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-2.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_3 wow bounceInDown " data-wow-delay="200ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-3.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_4 wow bounceInDown " data-wow-delay="300ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-4.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_5 wow bounceInDown " data-wow-delay="400ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-5.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_6 wow bounceInDown " data-wow-delay="500ms " data-wow-duration="1500ms ">
                              <img src="assets/image/resources/home-1-contact-6.png " class="img-fluid " alt="img " />
                           </figure>
                           <figure class="image image_bg ">
                              <img src="assets/image/resources/home-1-contact-bg.png " class="img-fluid " alt="img " />
                           </figure>
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            <section class="map-section">
               <!--Map Outer-->
               <div class="map-outer">
                  <div class="google-map" id="contact-google-map" data-map-lat="44.231172" data-map-lng="-76.485954" data-icon-path="assets/image/health.png" data-map-title="Alabama, USA" data-map-zoom="12" data-markers='{
                     "marker-1": [42.231172, -84.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-2": [44.231172, -76.485954, "<h4>Branch Office</h4><p>4/99 Alabama, USA</p>"],
                     "marker-3": [40.880550, -78.393705, "<h4>Branch Office</h4><p>4/99 Pennsylvania, USA</p>"]
                     }'>
                  </div>
               </div>
            </section>

            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>




            <?php
    if (isset($_POST["btn"])) {
       $user = $_SESSION["id"];
        $name = $_POST["hname"];
        $timing = $_POST["timing"];
        $days = $_POST["date"];
        $fees = $_POST["fees"];
        $address = $_POST["address"];
        $status = "nonapprove";
    

        require_once("../Connection.php");

        
            $query ="INSERT INTO `appoinment`(`hospital_id`, `user_id`, `timing`, `day`, `fees`, `status`) VALUES 
             ('$ID','$user','$timing','$days','$fees','$status')";
            $run = mysqli_query($con , $query);
            if ($run == true) {
                echo '<script>          
                alert("Your Request has been submited we will responed you leter");
                </script>';

            } else {
                echo mysqli_error($con);
            }
            
        }


?>
            <?php
include_once("footer.php");
?>
 