<?php

    session_start();
    if(!isset( $_SESSION["role"] ))
    {
        header("location:../Dashboard/login.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
      <meta name="title" content="Corona">
      <meta property="fb:app_id" content="312" />
      <meta property="og:type" content="Corona" />
      <meta property="og:url" content="http://steelthemes.com/demo/Elango/Corona-final" />
      <meta property="og:title" content="Corona">
      <meta property="og:image" content="http://steelthemes.com/demo/Elango/Corona-final/assets/image/fbimg-210x210.jpg">
      <meta property="og:description" content="Corona is html 5 Template">
      <meta name="full-screen" content="yes">
      <meta name="theme-color" content="#269bef">
      <!-- Responsive -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
      <title>Corano</title>
      <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="assets/css/style.css">
      <link rel="stylesheet" type="text/css" href="assets/fonts/font/flaticon.css">
      <!---------favicon--------------->
      <link rel="icon" type="image/png" href="assets/image/favicon-32x32.png" sizes="32x32">
      <link rel="icon" type="image/png" href="assets/image/favicon-16x16.png" sizes="16x16">
      <!---------favicon--------------->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
      <link rel="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" href="style.css">
   
</head>
<body class="home_page_one">
<div class="page_wapper">
          <!--Start Preloader-->
          <div class="preloader">
            <div class="preloader_box">
               <div class="loader">
                  <div class="circle item0"></div>
                  <div class="circle item1"></div>
                  <div class="circle item2"></div>
               </div>
            </div>
         </div>
         <!--End Preloader -->
         <!--Header-->
         <header class="header_v2">
            <section class="header_top">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-8">
                        <div class="row">
                           <div class="col-lg-3 col-md-3">
                              <div class="heading">
                                 <h2>Today Updates</h2>
                              </div>
                           </div>
                           <div class="col-lg-9 col-md-9">
                              <div class="news_inner">
                                 <div class="owl-carousel owl-theme single_items">
                                    <div class="mid-text">
                                       <p><a href="#">Stabilitech's COVID-19 Vaccine Intended to Be Delivered in a Disruptive Thermally Stable Oral Capsule</a></p>
                                    </div>
                                    <div class="mid-text">
                                       <p><a href="#"> Controlled Release Drug Delivery Market Size Worth $69.8 Billion by 2027: Grand View Research, Inc.</a></p>
                                    </div>
                                    <div class="mid-text">
                                       <p><a href="#">  Drug Delivery Market Size Worth $69.8 Billion by 2027: Grand View Research, Inc.
                                          </a>
                                       </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="text_right">
                           <div class="social_media_icon">
                              <ul class="clearfix">
                                 <li>
                                    <a href="#" class="has-tooltip">
                                       <span  class="fa-brands fa-facebook-f"></span>
                                       <div class="c-tooltip">
                                          <div class="tooltip-inner">Facebook</div>
                                       </div>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="#" class="has-tooltip">
                                       <span  class="fa-brands fa-twitter"></span>
                                       <div class="c-tooltip">
                                          <div class="tooltip-inner">Twitter</div>
                                       </div>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="#" class="has-tooltip">
                                       <span  class="fa-brands fa-linkedin-in"></span>
                                       <div class="c-tooltip">
                                          <div class="tooltip-inner">Linkedin</div>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
         
            </section>
            <section class="navbar_outer">
               <div class="navbar navbar-expand-lg  bsnav bsnav-sticky bsnav-sticky-slide">
                  <div class="container-fluid">
                     <a class="navbar-brand" href="index.html"><img src="assets/image/home-1-logo.png" class="img-fluid" alt="img"></a>
                     <button class="navbar-toggler toggler-spring"><span class="navbar-toggler-icon"></span></button>
                     <div class="collapse navbar-collapse scroll-nav">
                        
                        <ul class="navbar-nav navbar-mobile navbar_left  ml-auto" id="nav">
                           
                          <?php
                          require_once("../connection.php");
                          if (isset($_SESSION["role"])) {
                            if ($_SESSION["role"] == "1") {
                             ?>
                            <li class="nav-item nav_item"> <a class="nav-link link_hd" href="index.php">  Home  </a></li>
 
                            <li class="nav-item nav_item"><a class="nav-link link_hd" href="patient_details_hos.php">P-List</a></li>
 
                            <li class="nav-item nav_item"> <a class="nav-link link_hd" href="appointment_approval.php">  Test Approval  </a></li>

                            <li class="nav-item nav_item"> <a class="nav-link link_hd" href="test_result.php"> Result  </a></li>
 
                            <li class="nav-item nav_item"><a class="nav-link link_hd" href="contact_view_patient.php">Customer Contact</a></li>

                            <li class="nav-item nav_item"><a class="nav-link link_hd" href="set_shedule.php">Set schedule</a></li>

                            <li class="nav-item nav_item"><a class="nav-link link_hd" href="Add_Vaccination.php">Add Vaccine</a></li>

                            <li class="nav-item nav_item"><a class="nav-link link_hd" href="vaccine_app_tbl.php">Vaccineation Approval</a></li>
 
                            <li class="nav-item nav_item"><a class="nav-link link_hd" href="contact_hospital.php">Contact</a></li>
                        

                             <?php
                            }
                            else if($_SESSION["role"] == "2")
                            {
                               ?>
                              <li class="nav-item nav_item"> <a class="nav-link link_hd" href="index.php">  Home  </a></li>
                            
                              <li class="nav-item nav_item"><a class="nav-link link_hd" href="about.php">About </a></li>
   
                              <li class="nav-item nav_item"><a class="nav-link link_hd" href="patient_details.php"> Profile</a></li>

                              <li class="nav-item nav_item"><a class="nav-link link_hd" href="hospital.php">Hospitals </a></li>
   
                              <li class="nav-item nav_item"> <a class="nav-link link_hd" href="test_result_show.php">  Results  </a></li>
   
                              <li class="nav-item nav_item"> <a class="nav-link link_hd" href="appoinment.php">Test Appointment</a></li>
   
                              <li class="nav-item nav_item"><a class="nav-link link_hd" href="show_vaccine.php">Vacine Appointment</a></li>
   
                              <li class="nav-item nav_item"><a class="nav-link link_hd" href="contact_patient.php">Contact</a></li>
                              <?php
                            }
                          }
                          ?>
                           
                        
                           
                           <li class="nav-item nav_item"><a class="nav-link link_hd" href="../logout.php" style="color:#D04083;">Log Out  <i class="fas fa-sign-out-alt"></i></a></li>

                        </ul>
                        <ul class="navbar-nav navbar-mobile navbar_right">
                           
                           <li class="nav-item  dropdown">
                           <!-- <a href="../logout.php">Log Out <i class="fas fa-sign-out-alt"></i></a> -->
                           </li>
                           <li class="nav-item  dropdown">
                              <!-- /.site-header__cart -->
                              <a href="#" class="site-header__sidemenu-nav side-menu__toggler">
                                 <span class="site-header__sidemenu-nav-line"></span>
                                 <!-- /.site-header__sidemenu-nav-line -->
                                 <span class="site-header__sidemenu-nav-line"></span>
                                 <!-- /.site-header__sidemenu-nav-line -->
                                 <span class="site-header__sidemenu-nav-line"></span>
                                 <!-- /.site-header__sidemenu-nav-line -->
                                 <!-- /.site-header__sidemenu -->
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </section>
         </header>
         <!--Header-->
    
</body>
</html>