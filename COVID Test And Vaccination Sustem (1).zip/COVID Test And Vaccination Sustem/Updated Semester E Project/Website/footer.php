<section class="footer type_two">
               <div class="footer_layer" style="background-image: url(assets/image/resources/footer-bg1.png);"></div>
               <div class="container">
                  <div class="row">
                     <div class="col-lg-3 col-xs-12">
                        <div class="footer_widgets tp_two first">
                           <h3 class="widgets_title logo">
                              <a href="index.html"><img src="assets/image/home-1-logo-white.png" class="img-fluid" alt="logo"></a>
                           </h3>
                           <div class="inner_widgets">
                              <p>A novel coronavirus is a new coronavirus that has not been previously identified. The virus causing coronavirus disease 2019 (COVID-19)</p>
                              <div class="social_media_icon">
                                 <ul class="clearfix">
                                    <li>
                                       <a href="#" class="has-tooltip">
                                          <span  class="fa-brands fa-facebook-f"></span>
                                          <div class="c-tooltip">
                                             <div class="tooltip-inner">Facebook</div>
                                          </div>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="#" class="has-tooltip">
                                          <span  class="fa-brands fa-twitter"></span>
                                          <div class="c-tooltip">
                                             <div class="tooltip-inner">Twitter</div>
                                          </div>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="#" class="has-tooltip">
                                          <span class="fa-brands fa-linkedin-in"></span>
                                          <div class="c-tooltip">
                                             <div class="tooltip-inner">Linkedin</div>
                                          </div>
                                       </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="footer_widgets tp_two">
                           <h3 class="widgets_title">Usefull links</h3>
                           <div class="inner_widgets">
                              <ul>
                                 <li><a href="#">Situation Reports</a></li>
                                 <li><a href="#">Advice For Public</a></li>
                                 <li><a href="#">Prevention</a></li>
                                 <li><a href="#">Coronavirus Symptoms</a></li>
                                 <li><a href="#">Donor & Partners</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="footer_widgets tp_two">
                           <h3 class="widgets_title">Contact us</h3>
                           <div class="inner_widgets">
                              <div class="text_box">
                                 <span class="fa fa-map-marker"></span>
                                 <p>124, Queens walk 2nd cross newyork 5241.</p>
                              </div>
                              <div class="text_box">
                                 <span class="fa fa-phone"></span>
                                 <p>+44 555 67 890</p>
                              </div>
                              <div class="text_box">
                                 <span class="fa fa-clock-o"></span>
                                 <p>Mon - Fri: 09.00 to 18.00</p>
                              </div>
                              <div class="text_box">
                                 <span class="fa fa-envelope"></span>
                                 <p>support@corano.com</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                        <div class="footer_widgets tp_two">
                           <h3 class="widgets_title">Newsletter</h3>
                           <div class="inner_widgets">
                              <p class="sub_description">Subscribe Us &amp; Recive Our Offers and Updates i Your Inbox Directly.</p>
                              <form>
                                 <input type="email" name="email" placeholder="Email Address..." />
                                 <button class="sub_btn" type="submit"><span class="flaticon-paper-plane"></span></button>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footer_last type_two">
                     <div class="row">
                        <div class="col-lg-12 text-center">
                           <p>Copyright © 2020 Aptech Students. All Rights Reserved.</p>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-------------main-centent-end--------------->
         </main>
         <!-------------pagewapper-end--------------->
      </div>
      <!--Scroll to top-->
      <a href="#" id="scroll" class="default-bg" style="display: inline;"><span class="fa fa-angle-up"></span></a>
      <!---------mbile-navbar----->
      <div class="bsnav-mobile">
         <div class="bsnav-mobile-overlay"></div>
         <div class="navbar">
            <button class="navbar-toggler toggler-spring mobile-toggler"><span class="fa fa-close"></span></button>
         </div>
      </div>
      <!---------mbile-navbar----->
      <!-- /.side-menu__block -->
      <div class="side-menu__block">
         <div class="side-menu__block-overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
         </div>
         <!-- /.side-menu__block-overlay -->
         <div class="side-menu__block-inner">
            <div class="row">
               <div class="col-lg-12">
                  <div class="logo_site">
                     <a href="index.html"><img src="assets/image/home-1-logo.png" alt="logo" /></a>
                  </div>
                  <div class="side-menu__block-contact">
                     <h2>Quick Online Consultancy Only on Few Minutes</h2>
                     <div class="form_outer">
                        <form>
                           <div class="from_group">
                              <input type="text" name="name" placeholder="Name" />
                           </div>
                           <div class="from_group">
                              <input type="email" name="email" placeholder="Email" />
                           </div>
                           <div class="from_group">
                              <input type="text" name="phone" placeholder="Phone" />
                           </div>
                           <div class="from_group">
                              <textarea rows="4" placeholder="Share Your Thoughts"></textarea>
                           </div>
                           <div class="from_group">
                              <button  class="theme_btn tp_two" type="submit">Contact Us</button>
                           </div>
                        </form>
                     </div>
                  </div>
                  <!-- /.side-menu__block-contact -->
                  <div class="side-menu__block-contact">
                     <h3 class="side-menu__block__title">Contact Us</h3>
                     <!-- /.side-menu__block__title -->
                     <ul class="side-menu__block-contact__list">
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-map-marker"></i> Rock St 12, Newyork City, USA
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-phone"></i>
                           <a href="tel:526-236-895-4732">(526) 236-895-4732</a>
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-envelope"></i>
                           <a href="mailto:example@mail.com">example@mail.com</a>
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-clock-o"></i> Week Days: 09.00 to 18.00 Sunday: Closed
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                     </ul>
                     <!-- /.side-menu__block-contact__list -->
                  </div>
                  <!-- /.side-menu__block-contact -->
                  <p class="side-menu__block__text site-footer__copy-text"><a href="#">Aptech Students</a> <i class="fa fa-copyright"></i> 2020 All Right Reserved</p>
               </div>
            </div>
            <!-- /.side-menu__block-inner -->
         </div>
      </div>
      <!-- /.side-menu__block -->
      <!-- /.search-popup -->
      <div class="search-popup">
         <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
         </div>
         <!-- /.search-popup__overlay -->
         <div class="search-popup__inner">
            <form action="#" class="search-popup__form">
               <input type="text" name="search" placeholder="Type here to Search....">
               <button type="submit"><i class="flaticon-magnifying-glass"></i></button>
            </form>
         </div>
         <!-- /.search-popup__inner -->
      </div>
      <!-- /.search-popup -->
      <!-----------------------------------script-------------------------------------->
      <script src="assets/js/jquery.js"></script>
      <script src="assets/js/popper.min.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/bsnav.min.js"></script>
      <script src="assets/js/jquery-ui.js"></script>

      <script src="assets/js/owl.js"></script>
      <script src="assets/js/wow.js"></script>
      <script src="assets/js/jquery.fancybox.js"></script>
      <script src="assets/js/TweenMax.min.js"></script>
      <script src="assets/js/validator.min.js"></script>
      <script src="assets/js/appear.js"></script>
      <script src="assets/js/moment.js"></script>
      <script src="assets/js/jquery.flexslider-min.js"></script>
      <script src="assets/js/pagenav.js"></script>
      <script src="assets/js/custom.js"></script>
      <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

      <script>
         $(document).ready( function () {
    $('#myTable').DataTable({"bLengthChange":false,"paging": false,"info":false})
    
} );
      </script>
   </body>
</html>