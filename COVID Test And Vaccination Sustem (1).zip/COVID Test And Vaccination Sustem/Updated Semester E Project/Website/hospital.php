<?php
 require_once("header.php");
?>

<main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="index.php">Home</a></li>
                              <li class="bread_crumb-item active">Hospitals</li>
                           </ul>
                           <h1>Search Hospitals</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            


<?php
    require_once("../connection.php");
   
//   $ids = $_SESSION["id"];
    $fetch = "select * from hospital"; 
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);
    $rec = mysqli_fetch_array($execute);
    

      ?>
    <section class="prevention_all">
    <div class="container">
       <div class="row">
         <?php

   if($num > 0) {
   
         while($rec = mysqli_fetch_array($execute)){

            ?>

                  <div class="col-lg-3">
                     <div class="icon_box type_two wow fadeIn " data-wow-delay="00ms" data-wow-duration="1500ms">
                        
                        <h2><a href="prevention-single.html"><?php echo $rec[2] ?></a></h2>
                        <div class="icon_box">
                        <img src="assets/image/svg/masksick.svg" class="img-fluid svg_icon" alt="img" />
                        <hr>
                        </div>
                        <p><?php echo $rec[3] ?></p>
                        <p><?php echo $rec[4] ?></p>

                        <?php
                        // echo"<a href='edit_profile.php?id=$rec[0]' class='read_more tp_one'><span class='flaticon-next' ></span></a>"; ?> 
                
                
                </div>
              </div>
             
          
                <?php



         }
      }
?>


        
                    
</div>
   </div>
</section>
    </main>   

    <br>
    <br>
    <br>
    <br>
    <br>
<?php
    require_once("Footer.php");


?>
