<?php
    require_once("../connection.php");
    require_once("header.php");
    $fetch = "select * from appoinment where status = 'approved'";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);
?>



 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="index.php">Home</a></li>
                              <li class="bread_crumb-item active">Test Result</li>
                           </ul>
                           <h1>Test Result</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
          
            <!-- info-section end -->
            <section class="contact_form type_one " >
               <div id="bubbles">
                  <figure class="image bubble_4 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-1.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_5 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-2.png " class="img-fluid " alt="img " />
                  </figure>
                  <figure class="image bubble_6 ">
                     <img src="assets/image/resources/home-1-contact-bubbles-3.png " class="img-fluid " alt="img " />
                  </figure>
               </div>
<br>
<br>
<br>
<br>
<br>
<?php
    if ($num > 0) {
      echo "<div class=''><table class='table table-border'>
           <tr>
               <th>Id</th>
               <th>Hospital ID</th>
               <th>User ID</th>
               <th>Timing</th>
               <th>Date</th>
               <th>Update Result</th>
              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){
            echo" <tr>
                <td>$rec[0]</td>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td>$rec[4]</td>
                <td><a href='result_update.php?idS=$rec[0]'>Update</a></td>
            </tr>";
       }
           echo "</table></div>";
    } 
    
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <?php
    require_once("Footer.php");


?>