<?php require_once("header.php"); ?>

<section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> Approve Vaccine</li>
                           </ul>
                           <h1>Vaccination</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>





<?php
    require_once("../connection.php");
    
    $fetch = "select * from approvevaccine ";
    
    $execute = mysqli_query($con,$fetch);
    $num = mysqli_num_rows($execute);
    ?>
<br>
<br>
<br>
<br>
<br>

<?php

    if ($num > 0) {
      echo "<div class='container'><table class='table table-border'>
           <tr>
               <th>User ID</th>
               <th>Vacine ID</th>
               <th>Status</th>
               <th>Approvel</th>
             
              
           </tr>";
       while($rec = mysqli_fetch_array($execute)){
            echo" <tr>
                <td>$rec[1]</td>
                <td>$rec[2]</td>
                <td>$rec[3]</td>
                <td><a href='vaccine_approvel.php?id=$rec[0]'>Approvel</a></td>
            </tr>";
       }
           echo "</table></div>";
    } else {
        header("location:");
    }
   
    ?>
    
    <br>
    <br>
    <br>
    <br>
    <br>
    <?php
   


?>
<?php require_once("Footer.php");?>