<?php
include_once("header.php");
?>
 <!------main-content------>
 <main class="main-content">
            <section class="page_title">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 d-flex">
                        <div class="content_box">
                           <ul class="bread_crumb text-center">
                              <li class="bread_crumb-item"><a href="#">Home</a></li>
                              <li class="bread_crumb-item active"> Prevention</li>
                           </ul>
                           <h1>Prevention</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!--------Checkout-------->
            <section class="prevention_all">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="00ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">Wash your hands often with soap</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/spongewash.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="100ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">Avoid touching your eyes, nose, and mouth</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/man-touch.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="200ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">Avoid close contact with people who are sick</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/socialspreading.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="300ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">Stay home if you are sick,  get medical care</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/sorethroat.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="400ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">Cover your mouth and nose with a tissue</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/masksick.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="500ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">Immediately wash your hands with  water</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/handwashwashing.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="600ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">If you are sick: You should wear a facemask</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/maskmedical.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="icon_box type_two wow fadeIn " data-wow-delay="700ms" data-wow-duration="1500ms">
                           <h2><a href="prevention-single.html">If surfaces are dirty, clean them</a></h2>
                           <div class="icon_box">
                              <img src="assets/image/svg/object-hygiene.svg" class="img-fluid svg_icon" alt="img" />
                           </div>
                           <p>at least 20 seconds especially after you have been in a public place.</p>
                           <a href="prevention-single.html" class="read_more tp_one">Read More <span class="flaticon-next "></span></a>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!--------Checkout-------->
<?php
include_once("footer.php");
?>