ADMIN LOGIN ID = admin@gmail.com ::: Paasword = admin

HOSPITAL LOGIN ID = fahad@gmail.com ::: Paasword = 123

PATIENT LOGIN ID = zaib@gmail.com ::: Paasword =123